﻿import express, { Request, Response, NextFunction } from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import cors from "cors";
import { Server } from "socket.io";
import { createServer } from "http";
import { spawn } from "child_process";
import { randomUUID } from "crypto";
import { readFileSync, existsSync, unlinkSync } from "fs";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import 'dotenv/config';

// Support both ESM and CJS
const __filename_esm = typeof __filename !== 'undefined'
  ? __filename
  : fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename_esm);

// -- Prisma --------------------------------------------------------------------
import * as PrismaClientPkg from "@prisma/client";

const prisma = new (PrismaClientPkg as any).PrismaClient();

// -- Firebase token verification (JWKS) ---------------------------------------
const FIREBASE_PROJECT_ID = "tickets-f4541";
const APP_JWT_SECRET = process.env.APP_JWT_SECRET || "retal-local-dev-secret";
let _cachedKeys: Record<string, string> = {};
let _keyCacheTime = 0;

async function getGooglePublicKeys(): Promise<Record<string, string>> {
  if (Date.now() - _keyCacheTime < 3_600_000 && Object.keys(_cachedKeys).length > 0) {
    return _cachedKeys;
  }
  const res = await fetch(
    "https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com"
  );
  _cachedKeys = (await res.json()) as Record<string, string>;
  _keyCacheTime = Date.now();
  return _cachedKeys;
}

interface FirebaseTokenPayload {
  sub: string;
  email?: string;
  name?: string;
  email_verified?: boolean;
}

interface AppTokenPayload {
  uid: string;
  email: string;
  type: "app";
}

async function verifyFirebaseToken(token: string): Promise<FirebaseTokenPayload> {
  const keys = await getGooglePublicKeys();
  const decoded = jwt.decode(token, { complete: true }) as any;
  if (!decoded) throw new Error("Invalid token");
  const cert = keys[decoded.header.kid];
  if (!cert) throw new Error("Key not found");
  const payload = jwt.verify(token, cert, {
    algorithms: ["RS256"],
    issuer: `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`,
    audience: FIREBASE_PROJECT_ID,
  }) as any;
  return { sub: payload.sub, email: payload.email, name: payload.name };
}

function signAppToken(payload: AppTokenPayload): string {
  return jwt.sign(payload, APP_JWT_SECRET, { expiresIn: "30d" });
}

function verifyAppToken(token: string): AppTokenPayload {
  const payload = jwt.verify(token, APP_JWT_SECRET) as jwt.JwtPayload;
  if (payload?.type !== "app" || typeof payload.uid !== "string" || typeof payload.email !== "string") {
    throw new Error("Invalid app token");
  }
  return {
    uid: payload.uid,
    email: payload.email,
    type: "app",
  };
}

// -- Auth middleware -----------------------------------------------------------
type AuthRequest = Request & { uid?: string; tokenEmail?: string; tokenName?: string };

const USER_ROLES = new Set(["admin", "engineer", "supervisor"]);
const USER_SPECIALTIES = new Set(["mechanics", "electricity", "general"]);

function asTrimmedString(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const v = value.trim();
  return v.length > 0 ? v : null;
}

function sanitizeSpecialties(input: unknown): string[] {
  if (!Array.isArray(input)) return [];
  const uniq = new Set<string>();
  for (const item of input) {
    if (typeof item !== "string") continue;
    const s = item.trim();
    if (USER_SPECIALTIES.has(s)) uniq.add(s);
  }
  return Array.from(uniq);
}

function normalizePhoneNumber(value: string | null): string | null {
  if (!value) return null;
  const normalized = value.replace(/\s+/g, "");
  return normalized.length > 0 ? normalized : null;
}

function toPublicUser<T extends Record<string, unknown> | null>(user: T) {
  if (!user) return user;
  const { passwordHash: _passwordHash, ...safeUser } = user as Record<string, unknown> & { passwordHash?: string | null };
  return safeUser;
}

function toPublicUsers<T extends Array<Record<string, unknown>>>(users: T) {
  return users.map((user) => toPublicUser(user));
}

async function assertUserIdentityUnique(employeeId: string | null, phoneNumber: string | null, excludeUid?: string) {
  const orWhere: Array<Record<string, string>> = [];
  if (employeeId) orWhere.push({ employeeId });
  if (phoneNumber) orWhere.push({ phoneNumber });
  if (orWhere.length === 0) return;

  const existing = await prisma.user.findFirst({
    where: {
      OR: orWhere,
      ...(excludeUid ? { uid: { not: excludeUid } } : {}),
    },
    select: { uid: true, employeeId: true, phoneNumber: true },
  });

    if (!existing) return;
  if (employeeId && existing.employeeId === employeeId) {
    throw new Error("رقم الموظف مستخدم بالفعل");
  }
  if (phoneNumber && existing.phoneNumber === phoneNumber) {
    throw new Error("رقم الهاتف مستخدم بالفعل");
  }
  throw new Error("بيانات الهوية موجودة مسبقاً");
}

async function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const token = header.slice(7);
  try {
    const appPayload = verifyAppToken(token);
    req.uid = appPayload.uid;
    req.tokenEmail = appPayload.email;
    next();
    return;
  } catch {}

  try {
    const payload = await verifyFirebaseToken(token);
    req.uid = payload.sub;
    req.tokenEmail = payload.email;
    req.tokenName = payload.name;
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
}

async function getRequesterRole(uid: string): Promise<string | null> {
  const user = await prisma.user.findUnique({ where: { uid }, select: { role: true } });
  return user?.role ?? null;
}

async function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  const uid = req.uid;
  if (!uid) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const role = await getRequesterRole(uid);
  if (role !== "admin") {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  next();
}

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: { origin: "*", methods: ["GET", "POST"] },
  });
  const PORT = 3001;

  app.use(cors());
  app.use(express.json({ limit: "10mb" }));

  // -- Health ----------------------------------------------------------------
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

  // --------------------------------------------------------------------------
  // AUTH (as in original � unchanged)
  // --------------------------------------------------------------------------

  app.post("/api/auth/login", async (req, res) => {
    const identifier = asTrimmedString(req.body?.identifier ?? req.body?.email ?? req.body?.phoneNumber);
    const password = asTrimmedString(req.body?.password);

    console.log('?? [Login] Attempt:', { identifier, passwordLength: password?.length });

    if (!identifier || !password) {
      res.status(400).json({ error: "?????? ?????????? ?? ??? ?????? ????? ?????? ???????" });
      return;
    }

    const isEmail = identifier.includes('@');
    
    let email: string | null = null;
    let phoneNumber: string | null = null;
    
    if (isEmail) {
      email = identifier.toLowerCase();
    } else {
      phoneNumber = normalizePhoneNumber(identifier);
      if (!phoneNumber) {
        res.status(400).json({ error: "???? ??? ?????? ??? ?????" });
        return;
      }
    }

    let user = null;
    if (email) {
      user = await prisma.user.findUnique({ where: { email } });
    } else if (phoneNumber) {
      user = await prisma.user.findFirst({ where: { phoneNumber } });
    }

    if (!user) {
      res.status(401).json({ error: "?????? ?????? ??? ?????" });
      return;
    }

    const isPending = user.uid.startsWith("pending_");

    if (isPending && !user.passwordHash) {
      const passwordHash = await bcrypt.hash(password, 10);
      await prisma.user.update({
        where: { uid: user.uid },
        data: { passwordHash },
      });
      const token = signAppToken({ uid: user.uid, email: user.email, type: "app" });
      res.json({ token, user: toPublicUser(user), requiresProfileCompletion: true, isFirstLogin: true });
      return;
    }

    if (user.passwordHash) {
      const passwordOk = await bcrypt.compare(password, user.passwordHash);
      if (passwordOk) {
        const token = signAppToken({ uid: user.uid, email: user.email, type: "app" });
        res.json({ token, user: toPublicUser(user), requiresProfileCompletion: isPending, isFirstLogin: false });
        return;
      }
    }

    res.status(401).json({ error: "?????? ?????? ??? ?????" });
  });

    // --------------------------------------------------------------------------
  // USERS
  // --------------------------------------------------------------------------


  app.post("/api/users/complete-profile", requireAuth, async (req: AuthRequest, res) => {
    const displayName = asTrimmedString(req.body?.displayName);
    const email = asTrimmedString(req.body?.email)?.toLowerCase();
    const newPassword = asTrimmedString(req.body?.password);

        if (!displayName || !email || !newPassword) {
      res.status(400).json({ error: "جميع الحقول مطلوبة" });
      return;
    }
    if (newPassword.length < 6) {
      res.status(400).json({ error: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" });
      return;
    }

    const currentUser = await prisma.user.findUnique({ where: { uid: req.uid! } });
    if (!currentUser || !currentUser.uid.startsWith("pending_")) {
      res.status(403).json({ error: "لا يمكنك إكمال بيانات حساب غير معلق" });
      return;
    }

    const existingEmail = await prisma.user.findUnique({ where: { email } });
    if (existingEmail && existingEmail.uid !== req.uid) {
      res.status(400).json({ error: "البريد الإلكتروني مستخدم بالفعل" });
      return;
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);
    const newUid = `user_${randomUUID()}`;

    try {
      const updatedUser = await prisma.$transaction(async (tx: any) => {
        await tx.user.delete({ where: { uid: req.uid! } });
        return await tx.user.create({
          data: {
            uid: newUid,
            email,
            passwordHash,
            displayName,
            role: currentUser.role,
            employeeId: currentUser.employeeId,
            phoneNumber: currentUser.phoneNumber,
            specialty: currentUser.specialty,
            specialties: currentUser.specialties,
            projectIds: currentUser.projectIds,
            photoURL: currentUser.photoURL,
            profileCompleted: true,
            notifPrefs: currentUser.notifPrefs ?? undefined,
          },
        });
      });
      const token = signAppToken({ uid: updatedUser.uid, email: updatedUser.email, type: "app" });
      res.json({ token, user: toPublicUser(updatedUser) });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.get("/api/users", requireAuth, async (_req, res) => {
    const users = await prisma.user.findMany({ orderBy: { createdAt: "asc" } });
    res.json(toPublicUsers(users));
  });

  app.get("/api/users/me", requireAuth, async (req: AuthRequest, res) => {
    const user = await prisma.user.findUnique({ where: { uid: req.uid! } });
    if (!user) { res.status(404).json({ error: "Not found" }); return; }
    res.json(toPublicUser(user));
  });

  app.post("/api/users/claim-pending", requireAuth, async (req: AuthRequest, res) => {
    const displayName = asTrimmedString(req.body?.displayName);
    const employeeId = asTrimmedString(req.body?.employeeId);
    const phoneNumberRaw = asTrimmedString(req.body?.phoneNumber);
    const phoneNumber = phoneNumberRaw ? phoneNumberRaw.replace(/\s+/g, "") : null;

    if (!displayName) {
      res.status(400).json({ error: "???? ????? ????? ??????" });
      return;
    }
    if (!employeeId && !phoneNumber) {
      res.status(400).json({ error: "??? ????? ????? ??????? ?? ??? ??????" });
      return;
    }
    if (phoneNumber && !/^\d{7,15}$/.test(phoneNumber)) {
      res.status(400).json({ error: "???? ??? ?????? ??? ?????" });
      return;
    }

    const existing = await prisma.user.findUnique({ where: { uid: req.uid! } });
    if (existing) {
      res.json(toPublicUser(existing));
      return;
    }

    const pending = await prisma.user.findFirst({
      where: {
        uid: { startsWith: "pending_" },
        OR: [
          ...(employeeId ? [{ employeeId }] : []),
          ...(phoneNumber ? [{ phoneNumber }] : []),
        ],
      },
    });




        if (!pending) {
      res.status(403).json({ error: "لم نتمكن من العثور على حساب معلق مطابق" });
      return;
    }

    const email = req.tokenEmail || `${req.uid}@pending.local`;
    try {
      const [claimed] = await prisma.$transaction([
        prisma.user.create({
          data: {
            uid: req.uid!,
            email,
            displayName,
            role: pending.role,
            employeeId: pending.employeeId,
            phoneNumber: pending.phoneNumber,
            specialty: pending.specialty,
            specialties: pending.specialties,
            projectIds: pending.projectIds,
            photoURL: pending.photoURL,
            profileCompleted: true,
            notifPrefs: pending.notifPrefs ?? undefined,
          },
        }),
        prisma.user.delete({ where: { uid: pending.uid } }),
      ]);
      res.status(201).json(toPublicUser(claimed));
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.get("/api/users/:uid", requireAuth, async (req, res) => {
    const user = await prisma.user.findUnique({ where: { uid: req.params.uid } });
    if (!user) { res.status(404).json({ error: "Not found" }); return; }
    res.json(toPublicUser(user));
  });

    app.post("/api/users", requireAuth, requireAdmin, async (req: AuthRequest, res) => {
    try {
      const data = req.body;
      const uidInput = asTrimmedString(data.uid);
      const role = asTrimmedString(data.role) || "engineer";
      if (!USER_ROLES.has(role)) throw new Error("الدور المحدد غير صالح");

      const employeeId = asTrimmedString(data.employeeId);
      const phoneNumber = asTrimmedString(data.phoneNumber);
      if (phoneNumber && !/^\d{7,15}$/.test(phoneNumber.replace(/\s+/g, ""))) {
        throw new Error("صيغة رقم الهاتف غير صالحة");
      }

      let specialties = sanitizeSpecialties(data.specialties);
      let projectIds = Array.isArray(data.projectIds)
        ? data.projectIds.filter((id: unknown) => typeof id === "string" && id.trim().length > 0)
        : [];

      if (role === "admin") {
        specialties = [];
        projectIds = [];
      }

      const specialty = specialties[0] || null;
      const displayName = asTrimmedString(data.displayName) || "";
      const photoURL = asTrimmedString(data.photoURL);

      let user;
      if (!uidInput) {
        const uid = `pending_${randomUUID()}`;
        const email = `${uid}@pending.local`;
        user = await prisma.user.create({
          data: {
            uid,
            email,
            displayName: displayName || "مستخدم جديد",
            role,
            employeeId,
            phoneNumber,
            specialty,
            specialties,
            projectIds,
            photoURL,
            profileCompleted: false,
            notifPrefs: data.notifPrefs ?? undefined,
          },
        });
      } else {
        if (!employeeId && !phoneNumber) {
          throw new Error("يجب إدخال رقم الموظف أو رقم الهاتف");
        }

        await assertUserIdentityUnique(employeeId, phoneNumber);

        const existingPending = await prisma.user.findFirst({
          where: {
            uid: { startsWith: "pending_" },
            OR: [
              ...(employeeId ? [{ employeeId }] : []),
              ...(phoneNumber ? [{ phoneNumber }] : []),
            ],
          },
        });

        if (existingPending) {
          user = await prisma.user.update({
            where: { uid: existingPending.uid },
            data: {
              displayName,
              role,
              employeeId,
              phoneNumber,
              specialty,
              specialties,
              projectIds,
              photoURL,
              profileCompleted: data.profileCompleted ?? false,
              notifPrefs: data.notifPrefs ?? undefined,
            },
          });
        } else {
          const uid = `pending_${randomUUID()}`;
          const email = `${uid}@pending.local`;
          user = await prisma.user.create({
            data: {
              uid,
              email,
              displayName,
              role,
              employeeId,
              phoneNumber,
              specialty,
              specialties,
              projectIds,
              photoURL,
              profileCompleted: data.profileCompleted ?? false,
              notifPrefs: data.notifPrefs ?? undefined,
            },
          });
        }
      }

      res.status(201).json(toPublicUser(user));
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // --------------------------------------------------------------------------
  app.get("/api/projects", requireAuth, async (_req, res) => {
    const projects = await prisma.project.findMany({ orderBy: { createdAt: "desc" } });
    res.json(projects);
  });

  app.get("/api/projects/:id", requireAuth, async (req, res) => {
    const project = await prisma.project.findUnique({
      where: { id: req.params.id },
      include: { clients: true },
    });
    if (!project) { res.status(404).json({ error: "Not found" }); return; }
    res.json(project);
  });

  app.post("/api/projects", requireAuth, async (req, res) => {
    const data = req.body;
    const project = await prisma.project.create({
      data: {
        name: data.name,
        location: data.location,
        abbreviation: data.abbreviation,
        engineerIds: data.engineerIds || [],
        supervisorIds: data.supervisorIds || [],
      },
    });
    res.status(201).json(project);
  });

  app.put("/api/projects/:id", requireAuth, async (req, res) => {
    const data = req.body;
    const project = await prisma.project.update({
      where: { id: req.params.id },
      data: {
        name: data.name ?? undefined,
        location: data.location ?? undefined,
        abbreviation: data.abbreviation ?? undefined,
        engineerIds: data.engineerIds ?? undefined,
        supervisorIds: data.supervisorIds ?? undefined,
      },
    });
    res.json(project);
  });

  app.delete("/api/projects/:id", requireAuth, async (req, res) => {
    await prisma.project.delete({ where: { id: req.params.id } });
    res.json({ success: true });
  });

  // --------------------------------------------------------------------------
  // CLIENTS (unchanged)
  // --------------------------------------------------------------------------
  app.get("/api/clients", requireAuth, async (_req, res) => {
    const clients = await prisma.client.findMany({ orderBy: { createdAt: "asc" } });
    res.json(clients);
  });

  app.get("/api/projects/:projectId/clients", requireAuth, async (req, res) => {
    const clients = await prisma.client.findMany({
      where: { projectId: req.params.projectId },
      orderBy: { name: "asc" },
    });
    res.json(clients);
  });

  app.post("/api/projects/:projectId/clients", requireAuth, async (req, res) => {
    const data = req.body;
    const client = await prisma.client.create({
      data: {
        projectId: req.params.projectId,
        name: data.name,
        phone: data.phone,
        villaNumber: data.villaNumber,
        blockNumber: data.blockNumber || null,
        handoverDate: data.handoverDate || null,
        warrantyExpiryDate: data.warrantyExpiryDate || null,
      },
    });
    res.status(201).json(client);
  });

  app.put("/api/clients/:id", requireAuth, async (req, res) => {
    const data = req.body;
    const client = await prisma.client.update({
      where: { id: req.params.id },
      data: {
        name: data.name ?? undefined,
        phone: data.phone ?? undefined,
        villaNumber: data.villaNumber ?? undefined,
        blockNumber: data.blockNumber ?? undefined,
        handoverDate: data.handoverDate ?? undefined,
        warrantyExpiryDate: data.warrantyExpiryDate ?? undefined,
      },
    });
    res.json(client);
  });

  app.delete("/api/clients/:id", requireAuth, async (req, res) => {
    await prisma.client.delete({ where: { id: req.params.id } });
    res.json({ success: true });
  });

  // --------------------------------------------------------------------------
  // TICKETS (with priority conversion and pending supervisor filtering)
  // --------------------------------------------------------------------------

  app.get("/api/tickets", requireAuth, async (req: AuthRequest, res) => {
    const { projectId, projectIds, supervisorId, status } = req.query as Record<string, string>;
    const where: any = {};
    if (projectId) where.projectId = projectId;
    if (projectIds) where.projectId = { in: projectIds.split(",") };
    if (supervisorId) where.assignedSupervisorIds = { has: supervisorId };
    if (status) where.status = status;
    const tickets = await prisma.ticket.findMany({
      where,
      orderBy: { createdAt: "desc" },
    });
    res.json(tickets);
  });

  app.get("/api/tickets/:id", requireAuth, async (req, res) => {
    const ticket = await prisma.ticket.findUnique({ where: { id: req.params.id } });
    if (!ticket) { res.status(404).json({ error: "Not found" }); return; }
    res.json(ticket);
  });

  app.post("/api/tickets", requireAuth, async (req, res) => {
    const data = req.body;
    try {
      const projectId = asTrimmedString(data.projectId);
      const clientId = asTrimmedString(data.clientId);
      if (!projectId || !clientId) {
                res.status(400).json({ error: "يجب تحديد المشروع والعميل لإنشاء التذكرة" });
        return;
      }

      const client = await prisma.client.findUnique({ where: { id: clientId }, select: { id: true, projectId: true } });
      if (!client || client.projectId !== projectId) {
        res.status(400).json({ error: "العميل المحدد غير موجود أو لا ينتمي لهذا المشروع" });
        return;
      }

      const assignedSupervisorIds = Array.isArray(data.assignedSupervisorIds)
        ? data.assignedSupervisorIds.filter((id: unknown) => typeof id === "string" && id.trim().length > 0 && !id.startsWith('pending_'))
        : [];

      let priority = 3;
      if (data.priority !== undefined) {
        const parsed = parseInt(data.priority, 10);
        priority = isNaN(parsed) ? 3 : parsed;
      }

      const ticket = await prisma.ticket.create({
        data: {
          ticketId: data.ticketId || String(Date.now()).slice(-6),
          refNumber: data.refNumber,
          projectAbbr: data.projectAbbr || null,
          projectId,
          clientId,
          clientName: data.clientName,
          villaNumber: data.villaNumber,
          issuedAt: data.issuedAt || null,
          description: data.description,
          type: data.type,
          status: data.status || "open",
          priority,
          assigneeName: data.assigneeName || null,
          assignedSupervisorId: (assignedSupervisorIds[0] && !assignedSupervisorIds[0].startsWith('pending_')) ? assignedSupervisorIds[0] : null,
          assignedSupervisorIds,
          assignedSupervisors: data.assignedSupervisors ?? undefined,
          detectedTypes: data.detectedTypes || [],
          appointmentTime: data.appointmentTime || null,
          appointmentNotes: data.appointmentNotes || null,
          closureNotes: data.closureNotes || null,
          maintenanceItems: data.maintenanceItems ?? undefined,
          closedAt: data.closedAt ? new Date(data.closedAt) : null,
        },
      });
      io.emit("ticket:created", ticket);
      res.status(201).json(ticket);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.post("/api/tickets/bulk", requireAuth, async (req, res) => {
    const tickets: any[] = req.body.tickets;
    if (!Array.isArray(tickets)) { res.status(400).json({ error: "tickets must be array" }); return; }
    try {
      const normalized = tickets.map((t, index) => {
        let assignedSupervisorIds = Array.isArray(t.assignedSupervisorIds)
          ? t.assignedSupervisorIds.filter((id: string) => id && !id.startsWith('pending_'))
          : [];
        let assignedSupervisorId = t.assignedSupervisorId && !t.assignedSupervisorId.startsWith('pending_')
          ? t.assignedSupervisorId
          : (assignedSupervisorIds[0] || null);

        let priority = 3;
        if (t.priority !== undefined) {
          const parsed = parseInt(t.priority, 10);
          priority = isNaN(parsed) ? 3 : parsed;
        }

        return {
          index,
          ticketId: t.ticketId || String(Date.now() + Math.random()).slice(-6),
          refNumber: t.refNumber,
          projectAbbr: t.projectAbbr || null,
          projectId: asTrimmedString(t.projectId) || "",
          clientId: asTrimmedString(t.clientId) || "",
          clientName: t.clientName,
          villaNumber: t.villaNumber,
          issuedAt: t.issuedAt || null,
          description: t.description,
          type: t.type || "general",
          status: t.status || "open",
          priority,
          assigneeName: t.assigneeName || null,
          assignedSupervisorId,
          assignedSupervisorIds,
          detectedTypes: t.detectedTypes || [],
          appointmentTime: t.appointmentTime || null,
          appointmentNotes: t.appointmentNotes || null,
        };
      });

      const missingSupervisors = normalized.filter(t => !t.assignedSupervisorId && t.assignedSupervisorIds.length === 0);
      if (missingSupervisors.length > 0) {

                console.warn(`⚠️ ${missingSupervisors.length} تذكرة بدون مشرف - سيتم تعيين لاحقاً`);
      }

            // Validate client-project relationship
      const invalidClientRefs: any[] = [];
      const clientCache = new Map<string, boolean>();
      for (const t of normalized) {
        if (t.projectId && t.clientId) {
          const cacheKey = `${t.projectId}:${t.clientId}`;
          let valid = clientCache.get(cacheKey);
          if (valid === undefined) {
            const client = await prisma.client.findFirst({
              where: { id: t.clientId, projectId: t.projectId },
              select: { id: true }
            });
            valid = !!client;
            clientCache.set(cacheKey, valid);
          }
          if (!valid) invalidClientRefs.push(t);
        } else {
          invalidClientRefs.push(t);
        }
      }
      if (invalidClientRefs.length > 0) {
        const sample = invalidClientRefs.slice(0, 5).map(t => t.ticketId || t.refNumber || `row-${t.index+1}`).join(", ");
        res.status(400).json({
          error: `???? ${invalidClientRefs.length} ????? ????? ??? ???? ?? ?? ???? ??????? (?????: ${sample})`,
        });
        return;
      }

      const created = await prisma.ticket.createMany({
        data: normalized.map(t => ({
          ticketId: t.ticketId,
          refNumber: t.refNumber,
          projectAbbr: t.projectAbbr,
          projectId: t.projectId,
          clientId: t.clientId,
          clientName: t.clientName,
          villaNumber: t.villaNumber,
          issuedAt: t.issuedAt,
          description: t.description,
          type: t.type,
          status: t.status,
          priority: t.priority,
          assigneeName: t.assigneeName,
          assignedSupervisorId: t.assignedSupervisorId,
          assignedSupervisorIds: t.assignedSupervisorIds,
          detectedTypes: t.detectedTypes,
          appointmentTime: t.appointmentTime,
          appointmentNotes: t.appointmentNotes,
        })),
        skipDuplicates: true,
      });
      res.status(201).json({ count: created.count });
    } catch (err: any) {
      console.error("Bulk import error:", err);
      res.status(400).json({ error: err.message });
    }
  });

  app.put("/api/tickets/:id", requireAuth, async (req, res) => {
    const data = req.body;
    try {
      const ticket = await prisma.ticket.update({
        where: { id: req.params.id },
        data: {
          status: data.status ?? undefined,
          priority: data.priority !== undefined ? String(data.priority) : undefined,
          assigneeName: data.assigneeName ?? undefined,
          assignedSupervisorId: data.assignedSupervisorId ?? undefined,
          assignedSupervisorIds: data.assignedSupervisorIds ?? undefined,
          assignedSupervisors: data.assignedSupervisors ?? undefined,
          appointmentTime: data.appointmentTime ?? undefined,
          appointmentNotes: data.appointmentNotes ?? undefined,
          closureNotes: data.closureNotes ?? undefined,
          maintenanceItems: data.maintenanceItems ?? undefined,
          closedAt: data.closedAt !== undefined ? (data.closedAt ? new Date(data.closedAt) : null) : undefined,
          description: data.description ?? undefined,
          type: data.type ?? undefined,
        },
      });
      res.json(ticket);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.patch("/api/tickets/bulk-status", requireAuth, async (req, res) => {
    const { ids, status } = req.body as { ids: string[]; status: string };
    await prisma.ticket.updateMany({ where: { id: { in: ids } }, data: { status } });
    res.json({ count: ids.length });
  });

  app.delete("/api/tickets/:id", requireAuth, async (req, res) => {
    await prisma.ticket.delete({ where: { id: req.params.id } });
    res.json({ success: true });
  });

  app.delete("/api/tickets", requireAuth, async (_req, res) => {
    const result = await prisma.ticket.deleteMany();
    res.json({ count: result.count });
  });

  // --------------------------------------------------------------------------
  // TECHNICIANS (with existence check to avoid crashing)
  // --------------------------------------------------------------------------
  function prismaModelExists(modelName: string): boolean {
    try {
      return (prisma as any)[modelName] !== undefined;
    } catch {
      return false;
    }
  }

    const hasTechnician = prismaModelExists('technician');
  if (hasTechnician) {
    app.get("/api/technicians", requireAuth, async (_req, res) => {
      const technicians = await prisma.technician.findMany({ orderBy: { name: "asc" } });
      res.json(technicians);
    });

    app.post("/api/technicians", requireAuth, async (req, res) => {
      const data = req.body;
      const tech = await prisma.technician.create({
        data: {
          employeeId: data.employeeId || null,
          phoneNumber: data.phoneNumber || null,
          specialty: data.specialty || null,
          experienceLevel: data.experienceLevel || null,
          supervisorId: data.supervisorId,
          projectId: data.projectId,
          name: data.name,
          idNumber: data.idNumber || null,
          idPhotoUrl: data.idPhotoUrl || null,
          documentUrls: data.documentUrls || [],
          clothingSize: data.clothingSize || null,
          shoeSize: data.shoeSize || null,
        },
      });
      res.status(201).json(tech);
    });

    app.put("/api/technicians/:id", requireAuth, async (req, res) => {
      const data = req.body;
      const tech = await prisma.technician.update({
        where: { id: req.params.id },
        data: {
          employeeId: data.employeeId ?? undefined,
          phoneNumber: data.phoneNumber ?? undefined,
          specialty: data.specialty ?? undefined,
          experienceLevel: data.experienceLevel ?? undefined,
          supervisorId: data.supervisorId ?? undefined,
          projectId: data.projectId ?? undefined,
          name: data.name ?? undefined,
          idNumber: data.idNumber ?? undefined,
          idPhotoUrl: data.idPhotoUrl ?? undefined,
          documentUrls: data.documentUrls ?? undefined,
          clothingSize: data.clothingSize ?? undefined,
          shoeSize: data.shoeSize ?? undefined,
        },
      });
      res.json(tech);
    });

    app.delete("/api/technicians/:id", requireAuth, async (req, res) => {
      await prisma.technician.delete({ where: { id: req.params.id } });
      res.json({ success: true });
    });
  } else {
    console.warn("⚠️ Technician model not found in Prisma schema. Technician endpoints disabled.");
    app.get("/api/technicians", (_req, res) => res.json([]));
    app.post("/api/technicians", (_req, res) => res.status(501).json({ error: "Technician model not available" }));
    app.put("/api/technicians/:id", (_req, res) => res.status(501).json({ error: "Technician model not available" }));
    app.delete("/api/technicians/:id", (_req, res) => res.status(501).json({ error: "Technician model not available" }));
  }

  // --------------------------------------------------------------------------
  // REPORT GENERATION (unchanged)
  // --------------------------------------------------------------------------
  app.post("/api/generate-report", (req, res) => {
    const scriptPath = path.join(__dirname, "report_generator.py");
    const pythonBin = process.platform === 'win32' ? 'python' : 'python3';
    const python = spawn(pythonBin, [scriptPath, "--stdin"], {
      env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' }
    });

    let output = "";
    let errorOutput = "";

    python.stdin.write(JSON.stringify(req.body));
    python.stdin.end();

    python.stdout.on("data", (data) => { output += data.toString(); });
    python.stderr.on("data", (data) => { errorOutput += data.toString(); });

    python.on("close", (code) => {
      if (code !== 0) {
        console.error("Python report error:", errorOutput);
        return res.status(500).json({ error: "Report generation failed", details: errorOutput });
      }
      const jpgPath = output.trim().split(/\r?\n/).pop() ?? "";
      if (!jpgPath || !existsSync(jpgPath)) {
        console.error("JPG not found at:", jpgPath, "stdout:", output);
        return res.status(500).json({ error: "Report file not found" });
      }
      try {
        const jpgData = readFileSync(jpgPath);
        res.setHeader("Content-Type", "image/jpeg");
        res.setHeader("Content-Disposition", `attachment; filename="report.jpg"`);
        res.send(jpgData);
        try { unlinkSync(jpgPath); } catch { /* ignore cleanup errors */ }
            } catch {
        res.status(500).json({ error: "Failed to read report file" });
      }
    });
  });

  // --------------------------------------------------------------------------
  // CLASSIFICATION API (تصنيف التذاكر باستخدام الذكاء الاصطناعي)
  // --------------------------------------------------------------------------

  // Cache ??????? ?????????
  let _kwCache: { keyword: string; typeKey: string; weight: number }[] = [];
  let _kwCacheTime = 0;
  const KW_CACHE_TTL = 5 * 60 * 1000;

  async function loadKeywordsFromDB(force = false) {
    if (!force && _kwCache.length > 0 && Date.now() - _kwCacheTime < KW_CACHE_TTL) {
      return _kwCache;
    }
    const rows = await prisma.ticketTypeKeyword.findMany({
      where: { typeId: { not: null }, ticketType: { isActive: true } },
      include: { ticketType: { select: { key: true } } },
    });
    _kwCache = rows
      .filter((r: any) => r.ticketType?.key)
      .map((r: any) => ({
        keyword: r.keyword,
        typeKey: r.ticketType.key,
        weight: r.weight,
      }));
    _kwCacheTime = Date.now();
    return _kwCache;
  }

  async function buildTypeToSpecialtyMap() {
    const types = await prisma.ticketType.findMany({
      where: { isActive: true },
      include: { specialty: { select: { key: true } } },
    });
    const map: Record<string, string> = {};
    for (const t of types) {
      map[t.key] = t.specialty?.key || "general";
    }
    return map;
  }

        // --------------------------------------------------------------------------
  // GEMINI AI CLASSIFICATION — ENHANCED (مع سياق كامل من قاعدة البيانات)
  // --------------------------------------------------------------------------

  const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";
  const GEMINI_MODEL = "gemini-2.5-flash"; // أحدث نموذج
  const VALID_TYPES = [
    "plumbing","electricity","doors_windows","cracks","ceramics",
    "tank_insulation","drainage","ac_ventilation","pumps",
    "waterproofing","grading","pest_control","cleaning","structural",
    "paints","doors",
  ];

  // ── Cache البيانات المرجعية لتزويد Gemini بالسياق ──────────────────────────
  let _refCache: {
    types: any[];
    specialties: any[];
    recentTickets: any[];
    keywords: any[];
  } = { types: [], specialties: [], recentTickets: [], keywords: [] };
  let _refCacheTime = 0;
  const REF_CACHE_TTL = 10 * 60 * 1000; // 10 دقائق

  /** تجميع كل البيانات المرجعية من DB عشان نزودها لـ Gemini */
  async function buildContextPayload(force = false) {
    if (!force && _refCache.types.length > 0 && Date.now() - _refCacheTime < REF_CACHE_TTL) {
      return _refCache;
    }

    const [types, specialties, recentTickets, keywords] = await Promise.all([
      prisma.ticketType.findMany({
        where: { isActive: true },
        include: {
          specialty: { select: { key: true, nameAr: true } },
          subTypes: { where: { isActive: true }, select: { nameAr: true, description: true }, orderBy: { sortOrder: "asc" } },
          _count: { select: { keywords: true, tickets: true } },
        },
        orderBy: { sortOrder: "asc" },
      }),
      prisma.specialty.findMany({
        where: { isActive: true },
        orderBy: { sortOrder: "asc" },
      }),
      prisma.ticket.findMany({
        take: 50,
        orderBy: { createdAt: "desc" },
        select: { description: true, type: true, status: true },
        where: { type: { not: "" } },
      }),
      prisma.ticketTypeKeyword.findMany({
        where: { typeId: { not: null } },
        select: { keyword: true, weight: true, ticketType: { select: { key: true, nameAr: true } } },
        orderBy: { weight: "desc" },
        take: 200,
      }),
    ]);

    _refCache = { types, specialties, recentTickets, keywords };
    _refCacheTime = Date.now();
    return _refCache;
  }

  /** بناء Prompt غني بالسياق لـ Gemini */
  async function buildRichPrompt(description: string, projectId?: string): Promise<string> {
    const ctx = await buildContextPayload();

    // 1. أنواع التذاكر
    const typesList = ctx.types.map(t =>
      `  - "${t.key}" (${t.nameAr}) ← تخصص: ${t.specialty?.nameAr || "عام"} | كلمات مفتاحية: ${t._count.keywords} | تذاكر سابقة: ${t._count.tickets}${t.subTypes.length ? ` | أنواع فرعية: ${t.subTypes.map(s => s.nameAr).join("، ")}` : ""}`
    ).join("\n");

    // 2. التخصصات
    const specialtiesList = ctx.specialties.map(s =>
      `  - "${s.key}" ← ${s.nameAr}`
    ).join("\n");

    // 3. أمثلة من التذاكر السابقة (للتعلم)
    const recentExamples = ctx.recentTickets.slice(0, 10).map(t =>
      `  - وصف: "${(t.description || "").slice(0, 120)}" ← النوع: "${t.type}" (الحالة: ${t.status})`
    ).join("\n\n");

    // 4. أقوى الكلمات المفتاحية
    const topKeywords = ctx.keywords.slice(0, 40).map(k =>
      `  - "${k.keyword}" ← ${k.ticketType?.nameAr || k.ticketType?.key} (وزن: ${k.weight})`
    ).join("\n");

    // 5. معلومات المشروع (اختياري)
    let projectInfo = "";
    if (projectId) {
      try {
        const project = await prisma.project.findUnique({
          where: { id: projectId },
          include: { clients: { take: 5, select: { villaNumber: true, name: true } } },
        });
        if (project) {
          projectInfo = `\nمعلومات المشروع:\n  الاسم: ${project.name}\n  الموقع: ${project.location}\n  العملاء المسجلون: ${project.clients.length}\n`;
          const supsInProject = await prisma.user.count({
            where: { role: "supervisor", projectIds: { has: projectId } },
          });
          projectInfo += `  المشرفون المخصصون: ${supsInProject}\n`;
        }
      } catch {}
    }

    return `أنت خبير متخصص في تصنيف تذاكر الصيانة العقارية (بعد البيع). 
أمامك قاعدة معرفة كاملة من النظام تشمل أنواع التذاكر المعتمدة، التخصصات، أمثلة من التذاكر السابقة، والكلمات المفتاحية.
استخدم هذه المعرفة لتصنيف الوصف الجديد بدقة.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧠 **قاعدة المعرفة من النظام:**

**التخصصات:**
${specialtiesList}

**أنواع التذاكر المعتمدة (مع كل التفاصيل):**
${typesList}

**أمثلة من التذاكر السابقة المصنفة (للاسترشاد):**
${recentExamples || "  (لا توجد تذاكر سابقة بعد)"}

**قاموس الكلمات المفتاحية المستخدمة:**
${topKeywords || "  (لا توجد كلمات مفتاحية بعد)"}
${projectInfo}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**الوصف الجديد المطلوب تصنيفه:** "${description}"

**تعليمات صارمة:**
1. اختر TYPE واحد أساسي من القائمة أعلاه (primaryType)
2. إذا كان الوصف يناسب أكثر من نوع، أدرجها في allTypes مرتبة حسب الأولوية
3. الدرجة (confidence) من 1 إلى 10 — كلما كان الوصف واضحًا والتطابق قويًا، زادت الدرجة
4. اشرح سبب اختيارك (reason) بالعربية — مثلاً: "الكلمة المفتاحية X تطابقة مع النوع Y"
5. استخدم أمثلة التذاكر السابقة للاسترشاد إذا كانت مشابهة للوصف الجديد
6. إذا كان الوصف غامضًا جدًا، اختر النوع الأقرب بدرجة ثقة منخفضة
7. مهم جدا: إذا كان هناك نوع جديد غير موجود في القائمة أعلاه وتعتقد أنه مهم ويستحق الإضافة، أضف suggestedNewType (key إنجليزي) واختر specialtyKey مناسب
8. مهم جدا: إذا كان هناك مشكلة محددة جداً تستحق أن تكون نوعاً فرعياً تحت النوع الأساسي (primaryType) وغير موجودة حالياً في الأنواع الفرعية أعلاه، أضف suggestedNewSubType (اسم بالعربية)
9. اقتراح الأنواع الجديدة فقط إذا كان الوصف يحتوي على مشكلة واضحة ومتكررة ومهمة

**أرجِع ONLY JSON بالتنسيق التالي (ممنوع markdown أو نصوص إضافية):**
{"primaryType":"...","allTypes":["..."],"confidence":8,"reason":"...","suggestedNewType":null,"suggestedNewSubType":null}`;
  }

    /** تصنيف التذكرة عبر Gemini مع سياق كامل */
  async function classifyWithGeminiEnhanced(description: string, projectId?: string): Promise<{
    primaryType: string;
    allTypes: string[];
    confidence: number;
    reason: string;
        suggestedNewType: string | null;
    suggestedNewSubType: string | null;
  } | null> {
    if (!GEMINI_API_KEY) return null;

    const prompt = await buildRichPrompt(description, projectId);

    try {
      const isNewKey = GEMINI_API_KEY.startsWith("AQ.");
      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (isNewKey) headers["x-goog-api-key"] = GEMINI_API_KEY;

      const res = await fetch(isNewKey ? apiUrl : `${apiUrl}?key=${GEMINI_API_KEY}`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.1, maxOutputTokens: 4096 },
        }),
      });

      if (!res.ok) {
        console.warn(`⚠️ Gemini API error: ${res.status} - ${await res.text().catch(() => 'no body')}`);
        return null;
      }

      const data = await res.json();
      const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      let text = rawText;
      if (!text) {
        const fc = data?.candidates?.[0]?.content?.parts?.[0]?.functionCall;
        if (fc?.args) text = JSON.stringify(fc.args);
      }
      if (!text) {
        console.warn("⚠️ Gemini returned empty response");
        return null;
      }

      return parseGeminiJsonResponse(text);
    } catch (err) {
      console.warn("⚠️ Gemini API call failed:", err);
      return null;
    }
  }

    /** تنظيف وتحليل رد JSON من Gemini */
    function parseGeminiJsonResponse(text: string): {
      primaryType: string;
      allTypes: string[];
      confidence: number;
      reason: string;
      suggestedNewType: string | null;
      suggestedNewSubType: string | null;
    } | null {
            try {
        let cleanJson = text.trim();
        console.log("  📋 Raw Gemini response length:", text.length, "trimmed:", cleanJson.length);
        console.log("  📋 Raw ends with:", JSON.stringify(cleanJson.slice(-50)));

        // Remove markdown code blocks (```json ... ``` or ``` ... ```)
        if (cleanJson.includes("```")) {
          // Split by newlines and filter out lines with backticks
          const lines = cleanJson.split('\n');
          const filteredLines = lines.filter(line => !line.trim().startsWith('```'));
          cleanJson = filteredLines.join('\n').trim();
        }

        // Find first { and last }
        const firstBrace = cleanJson.indexOf('{');
        const lastBrace = cleanJson.lastIndexOf('}');
        if (firstBrace !== -1 && lastBrace !== -1) {
          cleanJson = cleanJson.substring(firstBrace, lastBrace + 1);
        }

                console.log("  📋 Cleaned JSON:", cleanJson.slice(0, 300));

                // Try to fix Arabic single quotes used inside strings (Gemini issue)
        let result;
        try {
          result = JSON.parse(cleanJson);
        } catch {
          // Fix: Gemini sometimes returns Arabic quotes (', "`", "", etc.) inside JSON strings
          // Strategy: remove all control characters and problematic quotes
          // Replace smart quotes / single quotes / backticks with spaces
          cleanJson = cleanJson
            .replace(/['\u2018\u2019\u201A\u201B\u2032\u2035`\u00B4]/g, '')  // Remove all single-quote variants
            .replace(/["\u201C\u201D\u201E\u201F\u2033\u2036]/g, '"');       // Normalize double-quote variants to "
        
          // Fix doubled quotes that result from normalization
          cleanJson = cleanJson.replace(/""/g, '"');

                    console.log("  📋 Fixed JSON:", cleanJson.slice(0, 300));
          // Try brute-force parsing: remove characters one by one from the end
          let trimmed = cleanJson;
          let parseAttempt = null;
          while (trimmed.length > 20) {
            try {
              parseAttempt = JSON.parse(trimmed);
              break;
            } catch {
              // Remove last char and retry (handles stray chars after JSON)
              trimmed = trimmed.slice(0, -1);
            }
          }
          if (parseAttempt) {
            result = parseAttempt;
          } else {
            console.warn("  ⚠️ Could not parse JSON even after aggressive trimming");
            return null;
          }
        }
        if (!result.primaryType) return null;

                const validTypes = (result.allTypes || []).filter((t: string) => VALID_TYPES.includes(t));
        let finalTypes = validTypes.length > 0 ? validTypes : [result.primaryType];

        return {
          primaryType: result.primaryType,
          allTypes: finalTypes.slice(0, 3),
          confidence: result.confidence || 5,
          reason: result.reason || "",
          suggestedNewType: result.suggestedNewType || null,
          suggestedNewSubType: result.suggestedNewSubType || null,
        };
      } catch (parseErr) {
        console.warn("⚠️ Gemini JSON Parsing Failed:", parseErr instanceof Error ? parseErr.message : String(parseErr), "| Raw:", text.slice(0, 200));
        return null;
      }
    }

        /** التصنيف الرئيسي — Gemini مع سياق DB أولاً، ثم Keyword fallback */
  async function classifyTicket(
    description: string,
    projectId?: string
  ): Promise<{ primaryType: string; allTypes: string[]; confidence: number; source: string; reason?:   string; suggestedNewType: string | null; suggestedNewSubType: string | null }> {
    // 1) Gemini AI مع سياق كامل
    if (GEMINI_API_KEY) {
      const geminiResult = await classifyWithGeminiEnhanced(description, projectId);
      if (geminiResult && VALID_TYPES.includes(geminiResult.primaryType)) {
        console.log(`  ✅ Gemini classified: ${geminiResult.primaryType} (confidence=${geminiResult.confidence})`);
        
        // ✨ If Gemini suggested a new type, save it to DB
        if (geminiResult.suggestedNewType) {
          learnNewTypeFromGemini(geminiResult.suggestedNewType, geminiResult.primaryType, description).catch(() => {});
        }
        // ✨ If Gemini suggested a new sub-type, save it under the primaryType
        if (geminiResult.suggestedNewSubType) {
          learnNewSubTypeFromGemini(geminiResult.primaryType, geminiResult.suggestedNewSubType, description).catch(() => {});
        }
        
        return {
          primaryType: geminiResult.primaryType,
          allTypes: geminiResult.allTypes,
          confidence: geminiResult.confidence,
          source: "gemini",
          reason: geminiResult.reason,
          suggestedNewType: geminiResult.suggestedNewType,
          suggestedNewSubType: geminiResult.suggestedNewSubType,
        };
      }
      console.log("  ⚠️ Gemini result invalid, falling back to keywords");
    }

    // 2) Keyword-based fallback
    const keywords = await loadKeywordsFromDB();
    const kwResult = classifyFromKeywordsDB(description, keywords);
    return {
      primaryType: kwResult.primaryType,
      allTypes: kwResult.allTypes,
      confidence: kwResult.confidence,
      source: "keywords",
    };
  }

  // ── LEARN NEW TYPE FROM GEMINI SUGGESTION ─────────────────────────────────
  // لما Gemini يقترح نوع جديد (suggestedNewType)، نضيفه في DB
  async function learnNewTypeFromGemini(suggestedKey: string, parentTypeKey: string, description: string) {
    try {
      // نتأكد إنه مش موجود
      const existing = await prisma.ticketType.findUnique({ where: { key: suggestedKey } });
      if (existing) return;

      // نشوف التخصص بتاع الـ parent type (أو general)
      const parentType = await prisma.ticketType.findUnique({
        where: { key: parentTypeKey },
        include: { specialty: true },
      });
      const specialtyKey = parentType?.specialtyKey || "general";
      const specialties = await prisma.specialty.findMany({ where: { isActive: true } });
      const validSpecialtyKeys = new Set(specialties.map(s => s.key));
      const finalSpecialty = validSpecialtyKeys.has(specialtyKey) ? specialtyKey : "general";

      const maxOrder = await prisma.ticketType.aggregate({ _max: { sortOrder: true } });
      const nextOrder = (maxOrder._max.sortOrder || 0) + 1;

      // نستخرج اسم عربي من الـ prompt نفسه أو من description
      const nameAr = "صيانة " + suggestedKey.replace(/_/g, " ");
      
      const newType = await prisma.ticketType.create({
        data: {
          key: suggestedKey,
          nameAr,
          nameEn: suggestedKey,
          description: `تم إنشاؤه تلقائياً من تصنيف: ${description.slice(0, 200)}`,
          specialtyKey: finalSpecialty,
          sortOrder: nextOrder,
          isActive: true,
          color: `#${Math.floor(Math.random()*16777215).toString(16)}`,
          icon: "📋",
        },
      });

      // نضيف كلمات من الوصف كـ keywords
      const words = description
        .toLowerCase().replace(/[،,?.!;:""''\s]+/g, ' ').split(/\s+/)
        .filter(w => w.length > 2);
      for (const word of [...new Set(words)].slice(0, 5)) {
        await prisma.ticketTypeKeyword.upsert({
          where: { keyword_typeId: { keyword: word, typeId: newType.id } },
          update: { weight: { increment: 0.5 } },
          create: { keyword: word, typeId: newType.id, weight: 1.0, source: "gemini_suggested", isLearned: true, confidence: 0.7, usageCount: 1 },
        });
      }

      // نضيفه في VALID_TYPES عشان يستخدم فوراً
      VALID_TYPES.push(suggestedKey);

      console.log(`  🆕 Auto-created new type: "${suggestedKey}" (${nameAr})`);
      
      // مسح cache
      _refCacheTime = 0;
      _kwCache = []; _kwCacheTime = 0;
    } catch (err) {
      console.warn(`  ⚠️ Failed to learn new type "${suggestedKey}":`, err);
    }
  }

  // ── LEARN NEW SUB-TYPE FROM GEMINI SUGGESTION ─────────────────────────────
  async function learnNewSubTypeFromGemini(parentTypeKey: string, subTypeNameAr: string, description: string) {
    try {
      const parentType = await prisma.ticketType.findUnique({ where: { key: parentTypeKey } });
      if (!parentType) return;

      // نتأكد مش موجود
      const existing = await prisma.ticketSubType.findFirst({
        where: { parentTypeId: parentType.id, nameAr: subTypeNameAr, isActive: true },
      });
      if (existing) return;

      const maxOrder = await prisma.ticketSubType.aggregate({
        where: { parentTypeId: parentType.id },
        _max: { sortOrder: true },
      });
      const nextOrder = (maxOrder._max.sortOrder || 0) + 1;

      await prisma.ticketSubType.create({
        data: {
          parentTypeId: parentType.id,
          nameAr: subTypeNameAr,
          nameEn: subTypeNameAr,
          description: `تم إنشاؤه تلقائياً من: ${description.slice(0, 200)}`,
          sortOrder: nextOrder,
          isActive: true,
          specialtyKey: parentType.specialtyKey,
        },
      });

      console.log(`  🆕 Auto-created sub-type: "${subTypeNameAr}" under ${parentType.nameAr}`);
      
      _refCacheTime = 0;
    } catch (err) {
      console.warn(`  ⚠️ Failed to learn sub-type "${subTypeNameAr}":`, err);
    }
  }

  // ── AUTO-LEARN: تعلم تلقائي من التصنيفات الناجحة ──────────────────────────
  /** التعلم التلقائي: يحول تصنيفات Gemini إلى كلمات مفتاحية في DB */
  async function autoLearnFromClassification(description: string, typeKey: string, confidence: number): Promise<void> {
    if (confidence < 6 || !description || !typeKey) return; // نتعلم فقط من التصنيفات عالية الثقة

    try {
      const type = await prisma.ticketType.findUnique({ where: { key: typeKey } });
      if (!type) return;

      const stopWords = new Set([
        "في","من","الى","على","عن","مع","هذا","هذه","ذلك","تلك","التي","الذي",
        "كان","كانت","يكون","هو","هي","هم","انا","نحن","انت","انتم","يوجد",
        "لا","لم","لن","ما","قد","كل","بعض","غير","وقت","يوم","ساعة","الان",
        "اليوم","جدا","فقط","حتى","ايضا","او","و","ثم","لكن","اما","اذا",
        "لان","بسبب","حيث","بين","خلال","دون","قبل","بعد","تحت","فوق",
        "ال","اللي","الا","ان","ان","او","ب","ت","ث","ج","ح",
      ]);

      // استخراج الكلمات المهمة من الوصف
      const words = description
        .toLowerCase()
        .replace(/[،,?.!;:""'']/g, " ")
        .split(/\s+/)
        .filter(w => w.length > 2 && !stopWords.has(w) && isNaN(Number(w)));

      // تجاهل الكلمات المركبة المكررة
      const uniqueWords = [...new Set(words)].slice(0, 5);

      for (const word of uniqueWords) {
        // نتأكد إن الكلمة مش موجودة فعلاً لنوع تاني
        const existingOther = await prisma.ticketTypeKeyword.findFirst({
          where: { keyword: word, typeId: { not: type.id } },
        });
        if (existingOther) continue;

        // upsert الكلمة
        await prisma.ticketTypeKeyword.upsert({
          where: { keyword_typeId: { keyword: word, typeId: type.id } },
          update: {
            usageCount: { increment: 1 },
            weight: { increment: 0.2 },
            isLearned: true,
            source: "auto_learned",
          },
          create: {
            keyword: word,
            typeId: type.id,
            weight: 1.0,
            isLearned: true,
            source: "auto_learned",
            confidence: confidence / 10,
            usageCount: 1,
          },
        });
      }

      // تحديث Cache الكلمات المفتاحية
      _kwCache = [];
      _kwCacheTime = 0;

      if (uniqueWords.length > 0) {
        console.log(`  📚 Auto-learned ${uniqueWords.length} keywords for "${type.nameAr}" from classification`);
      }
    } catch (err) {
      console.warn("  ⚠️ Auto-learn failed:", err);
    }
  }

  const CONFLICTING_PAIRS: [string, string][] = [
    ["electricity", "plumbing"],
    ["electricity", "drainage"],
    ["electricity", "pumps"],
    ["electricity", "ac_ventilation"],
    ["electricity", "waterproofing"],
    ["electricity", "grading"],
    ["electricity", "pest_control"],
    ["electricity", "structural"],
    ["electricity", "tank_insulation"],
    ["plumbing", "electricity"],
    ["doors_windows", "electricity"],
    ["cracks", "pest_control"],
    ["cleaning", "structural"],
  ];

  function classifyFromKeywordsDB(
    description: string,
    keywords: { keyword: string; typeKey: string; weight: number }[]
  ): { primaryType: string; allTypes: string[]; confidence: number } {
    const text = description.toLowerCase();
    const scores: Record<string, number> = {};

    for (const kw of keywords) {
      if (text.includes(kw.keyword)) {
        scores[kw.typeKey] = (scores[kw.typeKey] || 0) + kw.weight;
      }
    }

    const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
    if (sorted.length === 0) {
      return { primaryType: "plumbing", allTypes: ["plumbing"], confidence: 0 };
    }

    const maxScore = sorted[0][1];
    const threshold = Math.max(3, maxScore * 0.5);

    // ???? ??????? ???? ??? ??????
    let candidates = sorted.filter(([, s]) => s >= threshold).map(([t]) => t);

    // ??? ??? type ?? ?????? "??????" ?? types ?? ?????? ??????
    // ????? ?? ???????? ???? score ???? ?? ???? ???? ?????
    if (candidates.includes("electricity") && candidates.length > 1) {
      const elecScore = scores["electricity"] || 0;
      // ???????? ???? ???? ?????? ?? ??? ????? 70% ?? ??????
      if (elecScore < maxScore * 0.7) {
        candidates = candidates.filter((t) => t !== "electricity");
      }
    }

    // ?? ??? ??? candidates ????? ???? ????? ?? ?? maxScore ???? ????? ?? ??????
    if (candidates.length > 3) {
      const secondScore = sorted[1]?.[1] || 0;
      if (maxScore > secondScore * 2.5) {
        candidates = [candidates[0]];
      } else if (maxScore > secondScore * 1.8) {
        candidates = candidates.slice(0, 2);
      }
    }

    // ??? ??????? ?????????
    const conflictSet = new Set(
      CONFLICTING_PAIRS.filter(
        ([a, b]) => candidates.includes(a) && candidates.includes(b)
      ).flat()
    );
    if (conflictSet.size > 0) {
      // ????? ??????? score ?? ?? ??? ??????
      const keep = new Map<string, number>();
      for (const c of candidates) {
        keep.set(c, scores[c] || 0);
      }
      // ??? ??? ??????? ???? ????? score
      for (const [a, b] of CONFLICTING_PAIRS) {
        if (keep.has(a) && keep.has(b)) {
          const [loser] = (keep.get(a) || 0) >= (keep.get(b) || 0) ? [b] : [a];
          keep.delete(loser);
        }
      }
      candidates = [...keep.keys()];
    }

    if (candidates.length === 0) candidates = [sorted[0][0]];
    return { primaryType: candidates[0], allTypes: candidates, confidence: maxScore };
  }

    async function findSupervisorsDB(projectId: string, requiredSpecialties: string[]) {
    const allUsers = await prisma.user.findMany({
      where: { role: "supervisor" },
      select: { uid: true, displayName: true, specialties: true, specialty: true, projectIds: true },
    });

    // ????? ??? pending users
    const activeUsers = allUsers.filter((u: any) => !u.uid.startsWith("pending_"));

    // ????? ??????? ??????
    let projectSups = activeUsers.filter(
      (u: any) => Array.isArray(u.projectIds) && u.projectIds.includes(projectId)
    );
    // Fallback: ?? ???????? ???????
    if (projectSups.length === 0) projectSups = activeUsers;

    const getSpecs = (u: any): string[] => {
      if (Array.isArray(u.specialties) && u.specialties.length > 0) return u.specialties;
      if (u.specialty) return [u.specialty];
      return ["general"];
    };

    // ???? ??? ?????? ???????
    let matched = projectSups.filter((s: any) =>
      getSpecs(s).some((sp: string) => requiredSpecialties.includes(sp))
    );

    // ?? ???? ?????? ????? ???? ????? ????? ?? ????????
    if (matched.length === 0) {
      // ??? general
      matched = projectSups.filter((s: any) => getSpecs(s).includes("general"));
    }
    if (matched.length === 0) {
      // ??? ??: ??? 3 ??????
      matched = projectSups.slice(0, 3);
    }

    return matched.map((u: any) => ({
      id: u.uid,
      name: u.displayName,
      specialties: getSpecs(u),
    }));
  }

    // POST /api/classify
  app.post("/api/classify", requireAuth, async (req, res) => {
    try {
      const { description, projectId } = req.body as { description: string; projectId: string };
      if (!description || !projectId) {
        res.status(400).json({ error: "description and projectId are required" });
        return;
      }

            const classification = await classifyTicket(description, projectId);
      const typeToSpecialty = await buildTypeToSpecialtyMap();
      const requiredSpecialties = [...new Set(classification.allTypes.map((t: string) => typeToSpecialty[t] || "general"))];
      const supervisors = await findSupervisorsDB(projectId, requiredSpecialties);

            // ✨ التعلم التلقائي من التصنيفات الناجحة
      if (classification.source === "gemini" && classification.confidence >= 6) {
        await autoLearnFromClassification(description, classification.primaryType, classification.confidence);
        // إعادة تحميل الـ Cache عشان الكلمات الجديدة تنفع فوراً
        _refCacheTime = 0;
      }

            res.json({
        primaryType: classification.primaryType,
        allTypes: classification.allTypes,
        requiredSpecialties,
        confidence: classification.confidence,
        source: classification.source,
        supervisors,
        reason: classification.reason || undefined,
        suggestedNewType: classification.suggestedNewType || undefined,
        suggestedNewSubType: classification.suggestedNewSubType || undefined,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

    // POST /api/classify/bulk
  app.post("/api/classify/bulk", requireAuth, async (req, res) => {
    try {
      const { items } = req.body as { items: { description: string; projectId: string }[] };
      if (!Array.isArray(items)) {
        res.status(400).json({ error: "items must be an array" });
        return;
      }

      const typeToSpecialty = await buildTypeToSpecialtyMap();

      const projectIds = [...new Set(items.map((i) => i.projectId))];
      const supervisorCache: Record<string, any[]> = {};
      for (const pid of projectIds) {
        supervisorCache[pid] = await prisma.user.findMany({
          where: { role: "supervisor", projectIds: { has: pid } },
          select: { uid: true, displayName: true, specialties: true, specialty: true },
        });
        if (supervisorCache[pid].length === 0) {
          supervisorCache[pid] = await prisma.user.findMany({
            where: { role: "supervisor" },
            select: { uid: true, displayName: true, specialties: true, specialty: true },
          });
        }
      }

      const getSpecs = (u: any): string[] => {
        if (Array.isArray(u.specialties) && u.specialties.length > 0) return u.specialties;
        if (u.specialty) return [u.specialty];
        return ["general"];
      };

            const results = await Promise.all(items.map(async (item) => {
        const classification = await classifyTicket(item.description, item.projectId);
        // ✨ تعلم تلقائي لكل تصنيف ناجح في bulk
        if (classification.source === "gemini" && classification.confidence >= 6) {
          await autoLearnFromClassification(item.description, classification.primaryType, classification.confidence);
        }
        const requiredSpecialties = [...new Set(classification.allTypes.map((t: string) => typeToSpecialty[t] || "general"))];
        const projectSups = supervisorCache[item.projectId] || [];

        const matched = projectSups.filter((s: any) =>
          getSpecs(s).some((sp: string) => requiredSpecialties.includes(sp))
        );
        const fallback = matched.length > 0
          ? matched
          : projectSups.filter((s: any) => getSpecs(s).includes("general"));
        const finalSups = fallback.length > 0 ? fallback : projectSups;

        return {
          primaryType: classification.primaryType,
          allTypes: classification.allTypes,
          requiredSpecialties,
          confidence: classification.confidence,
          source: classification.source,
          supervisors: finalSups.map((u: any) => ({
            id: u.uid,
            name: u.displayName,
            specialties: getSpecs(u),
          })),
        };
      }));

      res.json(results);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/tickets/import
  app.post("/api/tickets/import", requireAuth, async (req: AuthRequest, res) => {
    try {
      const { projectId, tickets: rawTickets } = req.body as {
        projectId: string;
        tickets: {
          ticketId?: string;
          refNumber?: string;
          clientId?: string;
          clientName?: string;
          villaNumber?: string;
          description?: string;
          type?: string;
          priority?: number | string;
          issuedAt?: string;
        }[];
      };

      if (!projectId || !Array.isArray(rawTickets) || rawTickets.length === 0) {
        res.status(400).json({ error: "projectId and tickets array are required" });
        return;
      }

      const projectClients = await prisma.client.findMany({
        where: { projectId },
        select: { id: true, villaNumber: true, name: true, phone: true },
      });
      const clientByVilla = Object.fromEntries(projectClients.map((c: any) => [c.villaNumber, c]));

      const projectSups = await prisma.user.findMany({
        where: { role: "supervisor", projectIds: { has: projectId } },
        select: { uid: true, displayName: true, specialties: true, specialty: true },
      });
      const allSups =
        projectSups.length > 0
          ? projectSups
          : await prisma.user.findMany({
              where: { role: "supervisor" },
              select: { uid: true, displayName: true, specialties: true, specialty: true },
            });

      const keywords = await loadKeywordsFromDB();
      const typeToSpecialty = await buildTypeToSpecialtyMap();

      const getSpecs = (u: any): string[] => {
        if (Array.isArray(u.specialties) && u.specialties.length > 0) return u.specialties;
        if (u.specialty) return [u.specialty];
        return ["general"];
      };

      const errors: { index: number; reason: string }[] = [];
      const ticketsToCreate: any[] = [];

      for (let i = 0; i < rawTickets.length; i++) {
        const raw = rawTickets[i];
        const description = (raw.description || "").trim();
        const villaNumber = (raw.villaNumber || "").trim();
        const clientId = (raw.clientId || "").trim();

        let matchedClientId = clientId;
        if (!matchedClientId && villaNumber) {
          matchedClientId = clientByVilla[villaNumber]?.id || "";
        }
        if (!matchedClientId) {
          errors.push({ index: i, reason: "No client found for villa " + villaNumber });
          continue;
        }

                let classification;
        if (GEMINI_API_KEY) {
          const geminiResult = await classifyWithGeminiEnhanced(description, projectId);
          if (geminiResult && VALID_TYPES.includes(geminiResult.primaryType)) {
            classification = { primaryType: geminiResult.primaryType, allTypes: geminiResult.allTypes, confidence: geminiResult.confidence };
            await autoLearnFromClassification(description, geminiResult.primaryType, geminiResult.confidence);
          } else {
            classification = classifyFromKeywordsDB(description, keywords);
          }
        } else {
          classification = classifyFromKeywordsDB(description, keywords);
        }
        const type = raw.type || classification.primaryType;

        const requiredSpecialties = [...new Set(classification.allTypes.map((t: string) => typeToSpecialty[t] || "general"))];
        const matchedSups = allSups.filter((s: any) => getSpecs(s).some((sp: string) => requiredSpecialties.includes(sp)));
        const finalSups = matchedSups.length > 0 ? matchedSups : allSups.filter((s: any) => getSpecs(s).includes("general"));
        const supervisorList = finalSups.length > 0 ? finalSups : allSups;
        const supervisorIds = supervisorList.map((s: any) => s.uid);
        const primarySup = supervisorList[0];
        const priorityNum = raw.priority !== undefined ? parseInt(String(raw.priority), 10) : 3;

        ticketsToCreate.push({
          ticketId: raw.ticketId || String(Date.now() + i).slice(-6),
          refNumber: raw.refNumber || "",
          projectAbbr: null,
          projectId,
          clientId: matchedClientId,
          clientName: clientByVilla[villaNumber]?.name || raw.clientName || "",
          villaNumber,
          issuedAt: raw.issuedAt || null,
          description,
          type,
          status: "open",
          priority: isNaN(priorityNum) ? 3 : priorityNum,
          assigneeName: primarySup?.displayName || null,
          assignedSupervisorId: primarySup?.uid || null,
          assignedSupervisorIds: supervisorIds,
          assignedSupervisors: supervisorList.map((s: any) => ({
            id: s.uid,
            name: s.displayName,
            specialty: getSpecs(s)[0],
          })),
          detectedTypes: classification.allTypes,
          appointmentTime: null,
          appointmentNotes: null,
        });
      }

      if (ticketsToCreate.length === 0) {
        res.json({ imported: 0, skipped: rawTickets.length, errors });
        return;
      }

      const created = await prisma.ticket.createMany({ data: ticketsToCreate, skipDuplicates: true });
      res.json({ imported: created.count, skipped: rawTickets.length - created.count, errors });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/classify/learn
  app.post("/api/classify/learn", requireAuth, async (req: AuthRequest, res) => {
    try {
      const { description, correctTypeKey } = req.body as {
        description: string;
        correctTypeKey: string;
      };
      if (!description || !correctTypeKey) {
        res.status(400).json({ error: "description and correctTypeKey are required" });
        return;
      }

      const correctType = await prisma.ticketType.findUnique({ where: { key: correctTypeKey } });
      if (!correctType) {
        res.status(400).json({ error: "Type '" + correctTypeKey + "' not found" });
        return;
      }

      const stopWords = new Set([
        "??","??","???","???","??","??","???","???","???","???","??","??",
        "??","??","??","??","??","??","???","???","???","???","????","??",
        "?","??","???","???","???","???","????","??","????","????","??????",
        "??????","????","????","????","????","?????","???","???","???","????","????",
        "???","???","????","???","???","???","???","???","???",
      ]);

      const words = description
        .toLowerCase()
        .split(/[\s,?.]+/)
        .filter((w) => w.length > 2 && !stopWords.has(w));

      let updated = 0;
      for (const word of [...new Set(words)]) {
        const existing = await prisma.ticketTypeKeyword.findUnique({
          where: { keyword_typeId: { keyword: word, typeId: correctType.id } },
        });
        if (existing) {
          await prisma.ticketTypeKeyword.update({
            where: { id: existing.id },
            data: { usageCount: existing.usageCount + 1, isLearned: true },
          });
        } else {
          const otherKeyword = await prisma.ticketTypeKeyword.findFirst({
            where: { keyword: word, typeId: { not: correctType.id } },
          });
          if (otherKeyword) {
            await prisma.ticketTypeKeyword.update({
              where: { id: otherKeyword.id },
              data: { confidence: Math.max(0.1, otherKeyword.confidence - 0.2) },
            });
          }
          await prisma.ticketTypeKeyword.create({
            data: {
              keyword: word,
              typeId: correctType.id,
              weight: 1.0,
              isLearned: true,
              source: "learned",
              confidence: 0.8,
              usageCount: 1,
            },
          });
          updated++;
        }
      }

      _kwCache = [];
      _kwCacheTime = 0;

      res.json({ learned: updated, message: "Learned " + updated + " new keywords for " + correctType.nameAr });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/classify/manual-keyword
  app.post("/api/classify/manual-keyword", requireAuth, requireAdmin, async (req: AuthRequest, res) => {
    try {
      const { keyword, typeKey, weight } = req.body as { keyword: string; typeKey: string; weight?: number };
      if (!keyword || !typeKey) {
        res.status(400).json({ error: "keyword and typeKey are required" });
        return;
      }

      const type = await prisma.ticketType.findUnique({ where: { key: typeKey } });
      if (!type) {
        res.status(400).json({ error: "Type '" + typeKey + "' not found" });
        return;
      }

      const existing = await prisma.ticketTypeKeyword.findUnique({
        where: { keyword_typeId: { keyword: keyword.trim().toLowerCase(), typeId: type.id } },
      });

      if (existing) {
        await prisma.ticketTypeKeyword.update({
          where: { id: existing.id },
          data: { weight: weight ?? existing.weight, source: "manual" },
        });
      } else {
        await prisma.ticketTypeKeyword.create({
          data: {
            keyword: keyword.trim().toLowerCase(),
            typeId: type.id,
            weight: weight ?? 1.0,
            source: "manual",
            isLearned: false,
            confidence: 1.0,
          },
        });
      }

      _kwCache = [];
      _kwCacheTime = 0;
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

    // POST /api/classify/auto-learn — تشغيل دورة تعلم يدوي
  app.post("/api/classify/auto-learn", requireAuth, requireAdmin, async (_req, res) => {
    try {
      // تشغيل في الخلفية
      runAutoLearnCycle().catch(console.error);
      res.json({ success: true, message: "Auto-learn cycle started in background" });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/classify/analytics — إحصائيات Gemini
  app.get("/api/classify/analytics", requireAuth, async (_req, res) => {
    try {
      const [totalTickets, withDetectedTypes, typeDistribution, keywordsCount, geminiCalls] = await Promise.all([
        prisma.ticket.count(),
        prisma.ticket.count({ where: { detectedTypes: { isEmpty: false } } }),
        prisma.ticket.groupBy({ by: ["type"], _count: true, orderBy: { _count: { type: "desc" } }, take: 20 }),
                prisma.ticketTypeKeyword.count({ where: { source: { equals: "auto_learned" } } }),
          prisma.ticketTypeKeyword.count({ where: { isLearned: true, source: { not: { equals: "seed" } } } }),
      ]);

      res.json({
        totalTickets,
        classifiedTickets: withDetectedTypes,
        classificationRate: totalTickets > 0 ? Math.round((withDetectedTypes / totalTickets) * 100) : 0,
        typeDistribution: typeDistribution.map((t: any) => ({ type: t.type, count: t._count })),
        learnedKeywords: { total: keywordsCount, auto: geminiCalls },
        geminiEnabled: !!GEMINI_API_KEY,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

    // GET /api/classify/types
  app.get("/api/classify/types", requireAuth, async (_req, res) => {
    try {
      const types = await prisma.ticketType.findMany({
        where: { isActive: true },
        include: {
          specialty: { select: { key: true, nameAr: true } },
          subTypes: {
            where: { isActive: true },
            include: { specialty: { select: { key: true, nameAr: true } } },
            orderBy: { sortOrder: "asc" },
          },
          _count: { select: { keywords: true } },
        },
        orderBy: { sortOrder: "asc" },
      });
      res.json(types);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── AUTO-GENERATE TICKET TYPES VIA GEMINI ────────────────────────────────
  // يسأل Gemini عن أنواع التذاكر المناسبة ويضيفها في قاعدة البيانات مباشرة
  app.post("/api/classify/generate-types", requireAuth, requireAdmin, async (_req, res) => {
    try {
      if (!GEMINI_API_KEY) {
        res.status(400).json({ error: "Gemini API key not configured" });
        return;
      }

      // 1. نجيب التخصصات الموجودة
      const specialties = await prisma.specialty.findMany({
        where: { isActive: true },
      });

      const specialtiesList = specialties.map(s =>
        `  - "${s.key}": ${s.nameAr}`
      ).join("\n");

      // 2. نجيب أنواع التذاكر الحالية عشان ما نكررش
      const existingTypes = await prisma.ticketType.findMany({
        select: { key: true, nameAr: true },
      });
      const existingKeys = new Set(existingTypes.map(t => t.key));

      // 3. نسأل Gemini يقترح أنواع تذاكر جديدة
      const prompt = `أنت خبير في تصنيف تذاكر الصيانة العقارية (بعد البيع).
أريدك تقترح أنواع تذاكر جديدة ومناسبة لمشروع صيانة عقارات سكنية وتجارية.

التخصصات المتاحة:
${specialtiesList}

أنواع التذاكر الموجودة حالياً (لا تكررها):
${existingTypes.map(t => `  - "${t.key}": ${t.nameAr}`).join("\n") || "  (لا يوجد)"}

المطلوب منك:
1. اقترح 5-8 أنواع تذاكر جديدة لم يتم ذكرها أعلاه
2. كل نوع يجب أن يكون له: key بالانجليزية (حروف صغيرة و underscores)، nameAr بالعربية، وصف مختصر، والتخصص المناسب
3. خلي الأنواع متنوعة وتغطي مجالات صيانة مختلفة (مثل: واجهات، مصاعد، غاز، أمن وسلامة، حمامات سباحة، لاندسكيب، مكافحة حريق، ستيل، زجاج، الواح شمسية، ...)
4. اختر التخصص (specialtyKey) من القائمة أعلاه
5. اقترح 2-3 كلمات مفتاحية لكل نوع جديد عشان نضيفها معاه

أرجِع ONLY JSON array بالتنسيق التالي (ممنوع markdown):
[
  {
    "key": "facades",
    "nameAr": "واجهات",
    "description": "صيانة وإصلاح واجهات المباني والكسوة الخارجية",
    "specialtyKey": "general",
    "keywords": ["واجهة", "حجر", "الومنيوم", "كلادينج"]
  }
]`;

      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
      const response = await fetch(`${apiUrl}?key=${GEMINI_API_KEY}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.3, maxOutputTokens: 2048 },
        }),
      });

      if (!response.ok) {
        res.status(500).json({ error: `Gemini API error: ${response.status}` });
        return;
      }

      const data = await response.json();
      let rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
      
      // Parse JSON from response
      let suggestedTypes;
      try {
        // Clean the response
        let clean = rawText.trim();
        if (clean.includes("```")) {
          const lines = clean.split('\n').filter(l => !l.trim().startsWith('```'));
          clean = lines.join('\n').trim();
        }
        const firstBracket = clean.indexOf('[');
        const lastBracket = clean.lastIndexOf(']');
        if (firstBracket !== -1 && lastBracket !== -1) {
          clean = clean.substring(firstBracket, lastBracket + 1);
        }
        suggestedTypes = JSON.parse(clean);
      } catch {
        res.status(500).json({ error: "Failed to parse Gemini response", raw: rawText.slice(0, 500) });
        return;
      }

      if (!Array.isArray(suggestedTypes) || suggestedTypes.length === 0) {
        res.json({ message: "No new types suggested", types: [] });
        return;
      }

      // 4. إضافة الأنواع الجديدة في DB
      const addedTypes: any[] = [];
      const errors: string[] = [];
      const validSpecialtyKeys = new Set(specialties.map(s => s.key));

      // نجيب أقصى sortOrder
      const maxOrder = await prisma.ticketType.aggregate({ _max: { sortOrder: true } });
      let nextOrder = (maxOrder._max.sortOrder || 0) + 1;

      for (const suggestion of suggestedTypes) {
        const key = (suggestion.key || "").trim().toLowerCase();
        const nameAr = (suggestion.nameAr || "").trim();
        const specialtyKey = (suggestion.specialtyKey || "").trim().toLowerCase();
        const keywords: string[] = Array.isArray(suggestion.keywords) 
          ? suggestion.keywords.filter((k: any) => typeof k === "string" && k.trim().length > 0).map((k: string) => k.trim().toLowerCase())
          : [];

        // Validation
        if (!key || !nameAr) {
          errors.push(`Invalid entry: missing key or nameAr (${JSON.stringify(suggestion)})`);
          continue;
        }
        if (existingKeys.has(key)) {
          errors.push(`Type "${key}" already exists`);
          continue;
        }
        if (!validSpecialtyKeys.has(specialtyKey)) {
          errors.push(`Type "${key}": specialty "${specialtyKey}" not found`);
          continue;
        }

        try {
          // Create the ticket type
          const newType = await prisma.ticketType.create({
            data: {
              key,
              nameAr,
              nameEn: key,
              description: (suggestion.description || "").trim().slice(0, 500),
              specialtyKey,
              sortOrder: nextOrder++,
              isActive: true,
              color: `#${Math.floor(Math.random()*16777215).toString(16)}`,
              icon: "📋",
            },
          });

          // Add keywords
          let addedKeywords = 0;
          for (const kw of keywords) {
            if (kw.length < 2) continue;
            try {
              await prisma.ticketTypeKeyword.create({
                data: {
                  keyword: kw,
                  typeId: newType.id,
                  weight: 1.5,
                  source: "gemini_generated",
                  isLearned: false,
                  confidence: 0.9,
                  usageCount: 0,
                },
              });
              addedKeywords++;
            } catch { /* keyword may already exist */ }
          }

          addedTypes.push({
            key: newType.key,
            nameAr: newType.nameAr,
            specialtyKey: newType.specialtyKey,
            keywordsAdded: addedKeywords,
          });

          existingKeys.add(key);
        } catch (err: any) {
          errors.push(`Failed to create "${key}": ${err.message}`);
        }
      }

      // 5. تحديث الـ Cache
      _refCacheTime = 0;
      _kwCache = [];
      _kwCacheTime = 0;

      res.json({
        message: `Added ${addedTypes.length} new types`,
        types: addedTypes,
        errors: errors.length > 0 ? errors : undefined,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/classify/generate-subtypes — يولد أنواع فرعية لنوع موجود
  app.post("/api/classify/generate-subtypes", requireAuth, requireAdmin, async (req, res) => {
    try {
      const { typeKey } = req.body as { typeKey: string };
      if (!typeKey) {
        res.status(400).json({ error: "typeKey is required" });
        return;
      }

      const parentType = await prisma.ticketType.findUnique({
        where: { key: typeKey },
        include: { specialty: true },
      });

      if (!parentType) {
        res.status(404).json({ error: `Type "${typeKey}" not found` });
        return;
      }

      const existingSubs = await prisma.ticketSubType.findMany({
        where: { parentTypeId: parentType.id, isActive: true },
        select: { nameAr: true },
      });
      const existingSubNames = new Set(existingSubs.map(s => s.nameAr));

      const prompt = `أنت خبير في الصيانة العقارية.
النوع الرئيسي: "${parentType.nameAr}" (${parentType.key})
التخصص: ${parentType.specialty?.nameAr || "عام"}

الأنواع الفرعية الموجودة حالياً (لا تكررها):
${existingSubs.map(s => `  - ${s.nameAr}`).join("\n") || "  (لا يوجد)"}

المطلوب: اقترح 5-8 أنواع فرعية جديدة وواقعية تحت هذا النوع.
كل نوع فرعي يجب أن يكون له اسم (nameAr) ووصف مختصر.
ركز على مشاكل الصيانة الشائعة.

أرجِع ONLY JSON array:
[
  { "nameAr": "تسريبات مياه من المواسير", "description": "إصلاح تسريبات المياه في المواسير الداخلية والخارجية" }
]`;

      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
      const response = await fetch(`${apiUrl}?key=${GEMINI_API_KEY}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.3, maxOutputTokens: 2048 },
        }),
      });

      if (!response.ok) {
        res.status(500).json({ error: `Gemini API error: ${response.status}` });
        return;
      }

      const data = await response.json();
      let rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";

      // Parse
      let suggestedSubs;
      try {
        let clean = rawText.trim();
        if (clean.includes("```")) {
          const lines = clean.split('\n').filter(l => !l.trim().startsWith('```'));
          clean = lines.join('\n').trim();
        }
        const firstBracket = clean.indexOf('[');
        const lastBracket = clean.lastIndexOf(']');
        if (firstBracket !== -1 && lastBracket !== -1) {
          clean = clean.substring(firstBracket, lastBracket + 1);
        }
        suggestedSubs = JSON.parse(clean);
      } catch {
        res.status(500).json({ error: "Failed to parse Gemini response", raw: rawText.slice(0, 500) });
        return;
      }

      const maxOrder = await prisma.ticketSubType.aggregate({
        where: { parentTypeId: parentType.id },
        _max: { sortOrder: true },
      });
      let nextOrder = (maxOrder._max.sortOrder || 0) + 1;
      const added: any[] = [];

      for (const sub of suggestedSubs) {
        const nameAr = (sub.nameAr || "").trim();
        if (!nameAr || existingSubNames.has(nameAr)) continue;

        try {
          await prisma.ticketSubType.create({
            data: {
              parentTypeId: parentType.id,
              nameAr,
              nameEn: nameAr,
              description: (sub.description || "").trim().slice(0, 500),
              sortOrder: nextOrder++,
              isActive: true,
              specialtyKey: parentType.specialtyKey,
            },
          });
          added.push({ nameAr });
          existingSubNames.add(nameAr);
        } catch {}
      }

      // Update cache
      _refCacheTime = 0;

      res.json({
        message: `Added ${added.length} new sub-types for "${parentType.nameAr}"`,
        subTypes: added,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

    // ── AUTO-LEARN CRON: تعلم دوري من التذاكر كل 6 ساعات ─────────────────────
  async function runAutoLearnCycle() {
    try {
      console.log("🔄 Auto-learn cycle started...");
      // نجيب التذاكر اللي ملهاش detectedTypes أو types غريبة
      const ticketsToLearn = await prisma.ticket.findMany({
        where: {
          OR: [
            { detectedTypes: { equals: [] } },
            { type: { in: ["general", "plumbing"] }, detectedTypes: { isEmpty: false } },
          ],
        },
        take: 30,
        orderBy: { createdAt: "desc" },
        select: { id: true, description: true, type: true },
      });

      if (ticketsToLearn.length === 0) {
        console.log("  ✅ No tickets to auto-learn");
        return;
      }

      let learned = 0;
      for (const ticket of ticketsToLearn) {
        if (!ticket.description || ticket.description.length < 5) continue;
        
        const classification = await classifyTicket(ticket.description);
        if (classification.source === "gemini" && classification.confidence >= 7) {
          await autoLearnFromClassification(ticket.description, classification.primaryType, classification.confidence);
          
          // تحديث التذكرة نفسها بالتصنيف الصحيح
          if (ticket.type === "general" || !ticket.type) {
            await prisma.ticket.update({
              where: { id: ticket.id },
              data: { type: classification.primaryType, detectedTypes: classification.allTypes },
            });
          }
          learned++;
        }
      }
      console.log(`  ✅ Auto-learn cycle: ${learned}/${ticketsToLearn.length} tickets processed`);
      _refCacheTime = 0;
      _kwCache = [];
      _kwCacheTime = 0;
    } catch (err) {
      console.error("  ❌ Auto-learn cycle error:", err);
    }
  }

    // تشغيل أول Auto-learn بعد 30 ثانية من بدء السيرفر
  setTimeout(() => runAutoLearnCycle(), 30_000);
  
  // ثم كل 6 ساعات
  setInterval(() => runAutoLearnCycle(), 6 * 60 * 60 * 1000);

  // ── AUTO-GENERATE TYPES: تشغيل مرة أول السيرفر وبعدين كل 24 ساعة ──────
  async function autoGenerateTypes() {
    if (!GEMINI_API_KEY) return;
    try {
      // نتأكد إن مفيش أنواع كتير أصلاً (أقل من 8)
      const count = await prisma.ticketType.count({ where: { isActive: true } });
      if (count >= 8) {
        console.log(`  ℹ️ Already have ${count} types, skipping auto-generate`);
        return;
      }
      
      console.log("  🤖 Auto-generating ticket types from Gemini...");
      
      const specialties = await prisma.specialty.findMany({
        where: { isActive: true },
      });
      const specialtiesList = specialties.map(s => `  - "${s.key}": ${s.nameAr}`).join("\n");

      const existingTypes = await prisma.ticketType.findMany({
        select: { key: true, nameAr: true },
      });
      const existingKeys = new Set(existingTypes.map(t => t.key));

      const prompt = `أقترح 6-10 أنواع تذاكر صيانة عقارية شاملة (بعد البيع).
التخصصات: ${specialtiesList}
لا تكرر: ${existingTypes.map(t => t.key).join(", ") || "لا يوجد"}
كل نوع: key إنجليزي, nameAr عربي, وصف, specialtyKey من القائمة, keywords (2-3 كلمات).
رد: JSON array فقط.`;

      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;
      const response = await fetch(`${apiUrl}?key=${GEMINI_API_KEY}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.3, maxOutputTokens: 2048 },
        }),
      });

      if (!response.ok) return;

      const data = await response.json();
      let rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
      
      let suggestions;
      try {
        let clean = rawText.trim();
        if (clean.includes("```")) clean = clean.split('\n').filter(l => !l.trim().startsWith('```')).join('\n').trim();
        const fb = clean.indexOf('['), lb = clean.lastIndexOf(']');
        if (fb !== -1 && lb !== -1) clean = clean.substring(fb, lb + 1);
        suggestions = JSON.parse(clean);
      } catch { return; }

      if (!Array.isArray(suggestions) || suggestions.length === 0) return;

      const validSpecialtyKeys = new Set(specialties.map(s => s.key));
      const maxOrder = await prisma.ticketType.aggregate({ _max: { sortOrder: true } });
      let nextOrder = (maxOrder._max.sortOrder || 0) + 1;
      let added = 0;

      for (const s of suggestions) {
        const key = (s.key || "").trim().toLowerCase();
        const nameAr = (s.nameAr || "").trim();
        const specialtyKey = (s.specialtyKey || "").trim().toLowerCase();
        const keywords: string[] = Array.isArray(s.keywords) ? s.keywords.filter((k: any) => typeof k === "string").map((k: string) => k.trim().toLowerCase()) : [];

        if (!key || !nameAr || existingKeys.has(key) || !validSpecialtyKeys.has(specialtyKey)) continue;

        try {
          const newType = await prisma.ticketType.create({
            data: {
              key, nameAr, nameEn: key,
              description: (s.description || "").trim().slice(0, 500),
              specialtyKey, sortOrder: nextOrder++, isActive: true,
              color: `#${Math.floor(Math.random()*16777215).toString(16)}`, icon: "📋",
            },
          });
          for (const kw of keywords) {
            if (kw.length < 2) continue;
            await prisma.ticketTypeKeyword.upsert({
              where: { keyword_typeId: { keyword: kw, typeId: newType.id } },
              update: {},
              create: { keyword: kw, typeId: newType.id, weight: 1.5, source: "auto_generated", isLearned: false, confidence: 0.9 },
            });
          }
          existingKeys.add(key);
          added++;
        } catch {}
      }

      if (added > 0) {
        console.log(`  ✅ Auto-generated ${added} new ticket types`);
        _refCacheTime = 0;
        _kwCache = []; _kwCacheTime = 0;
      }
    } catch (err) {
      console.warn("  ⚠️ Auto-generate types failed:", err);
    }
  }

  // أول مرة بعد 10 ثوان من بدء السيرفر
  setTimeout(() => autoGenerateTypes(), 10_000);
  // وكل 24 ساعة
  setInterval(() => autoGenerateTypes(), 24 * 60 * 60 * 1000);

  // -- Socket.io -------------------------------------------------------------
  io.on("connection", (socket) => {
    socket.on("ticket:assign", (data) => {
      io.emit("notification:assignment", data);
    });
  });

  // -- Static / Vite ---------------------------------------------------------
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Error starting server:", err);
});